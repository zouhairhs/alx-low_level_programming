https://intranet.alxswe.com/concepts/60
Will be modified
