#include "main.h"

/**
 * reset_to_98 - update the value of n by pointing to 98
 * @n: pointer to an int to update
 */
void reset_to_98(int *n)
{
	*n = 98;
}
