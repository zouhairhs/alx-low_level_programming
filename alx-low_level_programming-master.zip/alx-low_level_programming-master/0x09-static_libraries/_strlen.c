#include "main.h"
int _strlen(char *s)
{
	return (0);
}
