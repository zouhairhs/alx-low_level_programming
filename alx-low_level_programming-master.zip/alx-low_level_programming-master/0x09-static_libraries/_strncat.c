#include "main.h"
char *_strncat(char *dest, char *src, int n)
{
	return (0);
}
