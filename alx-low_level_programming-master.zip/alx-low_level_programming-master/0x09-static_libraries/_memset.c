#include "main.h"
char *_memset(char *s, char b, unsigned int n)
{
	return (0);
}
