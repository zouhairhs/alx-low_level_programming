#include "main.h"
char *_strcpy(char *dest, char *src)
{
	return (0);
}
