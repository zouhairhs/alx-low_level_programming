#include "main.h"
int _islower(int c)
{
	return (0);
}
