#include "main.h"
int _abs(int n)
{
	return (0);
}
