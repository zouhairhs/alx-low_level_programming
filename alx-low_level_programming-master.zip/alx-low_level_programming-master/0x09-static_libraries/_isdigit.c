#include "main.h"
int _isdigit(int c)
{
	return (0);
}
