#include "main.h"
char *_memcpy(char *dest, char *src, unsigned int n)
{
	return (0);
}
