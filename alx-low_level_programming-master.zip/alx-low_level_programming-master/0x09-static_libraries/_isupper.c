#include "main.h"
int _isupper(int c)
{
	return (0);
}
