#include "main.h"
char *_strpbrk(char *s, char *accept)
{
	return (0);
}
