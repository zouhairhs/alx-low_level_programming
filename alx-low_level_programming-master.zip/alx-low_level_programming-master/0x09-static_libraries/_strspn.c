#include "main.h"
unsigned int _strspn(char *s, char *accept)
{
	return (0);
}
