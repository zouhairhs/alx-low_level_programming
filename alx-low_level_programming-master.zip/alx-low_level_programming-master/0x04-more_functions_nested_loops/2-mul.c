#include "main.h"

/**
 * mul - multiply two integers
 * @a: first number to multiply
 * @b: second number to multiply
 *
 * Return: the product for a and b
 */
int mul(int a, int b)
{
	return (a * b);
}
