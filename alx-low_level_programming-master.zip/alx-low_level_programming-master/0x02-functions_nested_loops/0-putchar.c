#include "main.h"

/**
 * main - Entry point
 * Return:0
 */

int main(void)
{
char s[] = "_putchar\n";
int i = 0;
while (s[i])
{
_putchar(s[i]);
i++;
}
return (0);
}
