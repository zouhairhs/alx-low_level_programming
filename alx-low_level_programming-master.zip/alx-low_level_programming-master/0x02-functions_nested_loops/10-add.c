#include "main.h"
/**
* add - add the values of a and b
* @a: an integer
* @b: another integer
* Return: the value of a + b
*/
int add(int a, int b)
{
return (a + b);
}
