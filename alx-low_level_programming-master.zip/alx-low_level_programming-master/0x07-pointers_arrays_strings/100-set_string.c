/**
 * set_string - set value of a pointer to char
 *
 * @s: value from main
 * @to: value from main
 *
 * Return: Always 0 (Success)
 */


void set_string(char **s, char *to)
{
	*s = to;
}
